
/**
 * Truck class.
 */
public class Truck extends Car {

}
