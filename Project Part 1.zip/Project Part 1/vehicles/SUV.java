
/**
 * SUV class.
 */
public class SUV extends Car {

}
