
/**
 * Hatchback class.
 */
public class Hatchback extends Car {

}
