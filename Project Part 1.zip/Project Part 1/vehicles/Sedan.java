
/**
 * Sedan class.
 */
public class Sedan extends Car {

}
