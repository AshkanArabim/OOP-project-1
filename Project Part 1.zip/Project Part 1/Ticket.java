public class Ticket {
    
}
