/**
 * This is the main runner class.
 * @author Ashkan Arabi
 * @author James Newson
 * @author Ruben Martinez
 */

public class RunShop {
    /**
     * Main method.
     * 
     * @param args
     */
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
