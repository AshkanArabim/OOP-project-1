public class User extends Person {
    
    @Override
    public void login() {
        System.out.println("Logging in");
    }

    public void viewCars() {}

    public void purchaseCars() {}

    public void applyForMembershipI() {}
    
    public void viewTicket() {}
}
