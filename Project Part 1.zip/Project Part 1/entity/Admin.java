public class Admin extends Person {
    public void login() {
        System.out.println("Admin logging in");
    }
}
